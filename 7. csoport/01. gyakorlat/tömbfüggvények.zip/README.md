# 1. gyakorlat - Környezet felállítása, nyelvi alapok,tömbfüggvények

1. Canvas, követelmények
2. Github, Github asztali appja
3. VS code, Live Server bővítmény
4. Console, javascript alapok
5. Tömbfüggvények
6. Tömbfüggvények megismerése projekttel